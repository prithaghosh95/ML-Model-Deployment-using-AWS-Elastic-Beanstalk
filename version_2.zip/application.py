from flask import Flask,request,render_template,jsonify
import joblib
application=Flask(__name__)

vectorizer=joblib.load("vectorizer.pkl")
spam_ham_model=joblib.load("spam_ham_model.pkl")


@application.route('/',methods=['GET','POST'])
def spamorham():
    if "x" in request.args:
        message=request.args.get("x")
        vect_message=vectorizer.transform([message])
        result=spam_ham_model.predict(vect_message)[0]
        return jsonify({'input': request.args['x'], 'prediction': result})
    elif request.method == 'POST':
        result = {'x': request.form.get('x'), 'prediction': None}
        message=request.form['x']
        vect_message=vectorizer.transform([message])
        result['prediction']=spam_ham_model.predict(vect_message)[0]
        return render_template('result.html', result=result)
     
    return render_template('index.html')        

if __name__== '__main__':
    application.run()
    


